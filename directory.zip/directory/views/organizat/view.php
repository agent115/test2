<?php use yii\helpers\Html;?>
<?php $this->title='Организации';?>
<section>
	<div class="container">
		<div class="row">
			<div class="col-md-6 col-md-offset-3">
				<?php if(!empty($organization)):?>
						<?php foreach($organization as $ord):?>
                            <div class="maps"><?= $ord->mars ?></div>
						<h3><?=$ord->name?></a></h3>
						<p>Телефон:<?= $ord->phone?></p>
						<p>Телефон:<?= $ord->phone_2?></p>
						<p>Адрес:<?= $ord->adress?></p>
						<p>График:<?= $ord->grafic?></p>
					<?php endforeach;?>
		
					<?php endif;?>
			</div>
                    <div class="col-md-2 col-md-offset-1">
                        <?php foreach ($Category as $cat):?>
                        <a href="<?= \yii\helpers\Url::to(['category/view', 'id' => $cat['id']]) ?>"><?= Html::img("@web/{$cat-> description}",['class'=>'vidget'] )?></a>
                        <?php endforeach;?>
                    </div>
		</div>
	</div>
</section>