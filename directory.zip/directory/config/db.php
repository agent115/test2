<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=localhost;dbname=categs',
    'username' => 'root',
    'password' => 'root',
    'charset' => 'utf8',
];
